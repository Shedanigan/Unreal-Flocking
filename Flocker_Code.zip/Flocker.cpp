// Fill out your copyright notice in the Description page of Project Settings.
#define SEPERATION
#define ALIGNMENT
#define COHESION
#define PLAYER_TRACKING

#include "Flocker.h"
#include "Components/StaticMeshComponent.h"

// Sets default values
AFlocker::AFlocker()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	StatMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Static Mesh"));
	RootComponent = StatMesh;

	StatMesh->SetSimulatePhysics(false);

	float turn_mod_sum = 0.0f;
#ifdef SEPERATION
	turn_mod_sum += seperation_turn_rate;
#endif // SEPERATION
#ifdef ALIGNMENT
	turn_mod_sum += alignment_turn_rate;
#endif // ALIGNMENT
#ifdef COHESION
	turn_mod_sum += cohesion_turn_rate;
#endif // COHESION
#ifdef PLAYER_TRACKING
	turn_mod_sum += player_turn_rate;
#endif // PLAYER_TRACKING
	turn_mod_sum += original_turn_rate;

	float turn_mod = 1.0f / turn_mod_sum;
#ifdef SEPERATION
	seperation_turn_rate *= turn_mod;
#endif // SEPERATION
#ifdef ALIGNMENT
	alignment_turn_rate *= turn_mod;
#endif // ALIGNMENT
#ifdef COHESION
	cohesion_turn_rate *= turn_mod;
#endif // COHESION
#ifdef PLAYER_TRACKING
	player_turn_rate *= turn_mod;
#endif // PLAYER_TRACKING
	original_turn_rate *= turn_mod;
}

// Called when the game starts or when spawned
void AFlocker::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AFlocker::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	FVector current_location = this->GetActorLocation();
	FVector current_direction = this->GetActorForwardVector();

	FCollisionObjectQueryParams types_to_scan;
	types_to_scan.AddObjectTypesToQuery(ECC_WorldDynamic);

	FCollisionShape scan_space;
	scan_space.SetSphere(scan_range);

	TArray<FOverlapResult> objects_found;

	GetWorld()->OverlapMultiByObjectType(objects_found, current_location, FQuat::Identity, types_to_scan, scan_space);

	FVector alignment_sum = { 0.0f, 0.0f, 0.0f };
	FVector cohesion_sum = { 0.0f, 0.0f, 0.0f };
	int n_flockmates = 0;

	objects_found.Num();

	for (FOverlapResult Result : objects_found)
	{
		AActor* found_object = Result.GetActor();
		if (found_object->GetActorScale().X != this->GetActorScale().X) continue;

		++n_flockmates;

		FVector distance = found_object->GetActorLocation() - current_location;

		alignment_sum = alignment_sum + found_object->GetActorForwardVector();
		cohesion_sum = cohesion_sum + distance;
	}

	if (n_flockmates > 0)
	{
		alignment_sum = alignment_sum / n_flockmates;
		cohesion_sum = (cohesion_sum / n_flockmates).GetSafeNormal();
	}

	scan_space.SetSphere(sep_range);

	TArray<FOverlapResult> obj_too_close;

	GetWorld()->OverlapMultiByObjectType(obj_too_close, current_location, FQuat::Identity, types_to_scan, scan_space);

	FVector seperation_sum = { 0.0f, 0.0f, 0.0f };
	n_flockmates = 0;

	for (FOverlapResult Result : obj_too_close)
	{
		AActor* found_object = Result.GetActor();
		if (found_object->GetActorScale().X != this->GetActorScale().X) continue;

		++n_flockmates;

		FVector distance = found_object->GetActorLocation() - current_location;

		seperation_sum = seperation_sum - distance.GetSafeNormal();
	}

	if (n_flockmates > 0) seperation_sum = seperation_sum / n_flockmates;

	FVector player_location = GetWorld()->GetFirstPlayerController()->GetPawn()->GetActorLocation();
	FVector player_direction = player_location - current_location;
	player_direction = player_direction.GetSafeNormal();

	FVector new_direction = { 0.0f, 0.0f, 0.0f };

#ifdef SEPERATION
	new_direction = new_direction + seperation_sum * seperation_turn_rate;
#endif // SEPERATION
#ifdef ALIGNMENT
	new_direction = new_direction + alignment_sum * alignment_turn_rate;
#endif // ALIGNMENT
#ifdef COHESION
	new_direction = new_direction + cohesion_sum * cohesion_turn_rate;
#endif // COHESION
#ifdef PLAYER_TRACKING
	new_direction = new_direction + player_direction * player_turn_rate;
#endif // PLAYER_TRACKING
	new_direction = new_direction + current_direction * original_turn_rate;
	new_direction = new_direction.GetSafeNormal();

	float new_yaw = (float)(atan2(new_direction.Y, new_direction.X) * 180.0 / PI);
	float new_pitch = 0.0f;// new_direction.Z * 60.0f;
	float new_roll = 0.0f;
	FRotator new_rotator = {new_pitch, new_yaw, new_roll};

	FVector new_location = current_location + new_direction * speed * DeltaTime;

	//GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Black, FString::Printf(TEXT("Direction X: %f Y: %f Z: %f"), new_direction.X, new_direction.Y, new_direction.Z));
	//GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::White, FString::Printf(TEXT("Rotation Pitch: %f Yaw: %f Roll: %f"), new_rotator.Pitch, new_rotator.Yaw, new_rotator.Roll));

	this->SetActorLocationAndRotation(new_location, new_rotator);
}

